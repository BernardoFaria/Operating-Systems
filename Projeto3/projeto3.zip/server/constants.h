/* Sistemas Operativos, DEI/IST/ULisboa 2019-20 */

#ifndef CONSTANTS_H
#define CONSTANTS_H

#define MAX_COMMANDS 10             // passaram a ser 10 entradas
#define MAX_INPUT_SIZE 100
#define DELAY 5000

// if enabled => RWLOCK, else MUTEX
//#define RWLOCK

#endif /* CONSTANTS_H */
